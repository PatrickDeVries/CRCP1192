#ifndef SLIDE3_H
#define SLIDE3_H
#include "slide.h"

//inherets from Slide
class slide3 :public Slide
{
public:
    slide3();
    void printSlide();
};

#endif // SLIDE3_H
