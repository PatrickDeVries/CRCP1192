#ifndef SLIDE2_H
#define SLIDE2_H
#include "slide.h"

//inherets from Slide
class slide2: public Slide
{
public:
    slide2();
    void printSlide();
};

#endif // SLIDE2_H
