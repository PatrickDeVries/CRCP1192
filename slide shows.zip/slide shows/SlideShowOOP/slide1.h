#ifndef SLIDE1_H
#define SLIDE1_H
#include "slide.h"

//inherets from Slide
class Slide1 : public Slide
{
public:
    Slide1();
    void printSlide();
};

#endif // SLIDE1_H
