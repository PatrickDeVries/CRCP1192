#ifndef SLIDE4_H
#define SLIDE4_H
#include "slide.h"

//inherets from Slide
class slide4 : public Slide
{
public:
    slide4();
    void printSlide();
};

#endif // SLIDE4_H
